package com.group2;

public class Parameters {
  public static final int MAX_AGE = 25;

}
