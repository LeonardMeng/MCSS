package com.group2;

public enum DaisyType {
  WHITE,
  BLACK
}
